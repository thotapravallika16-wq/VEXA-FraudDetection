# ─── VEXA Fraud Detection — predictor.py ───

import pickle
import numpy as np

MERCHANT_RISK = {
    "Crypto Exchange": 0.90,
    "Unknown":         0.85,
    "Wire Transfer":   0.75,
    "Online Gaming":   0.65,
    "International":   0.60,
    "Food Delivery":   0.10,
    "Grocery":         0.08,
    "E-Commerce":      0.15,
    "Utility":         0.05,
    "Medical":         0.10,
}

_model = None


def _load_model():
    global _model
    if _model is None:
        try:
            with open("fraud_model.pkl", "rb") as f:
                _model = pickle.load(f)
        except Exception:
            _model = None
    return _model


def predict(amount: float, merchant: str, device: str = "known", hour: int = 12) -> float:
    """
    Returns a fraud probability score 0.0–1.0.
    Uses the trained ML model if available, else falls back to rules.
    """
    model = _load_model()
    merchant_score = MERCHANT_RISK.get(merchant, 0.30)

    if model is not None:
        try:
            # Map merchant to numeric (same encoding used during training)
            merchant_map = {m: i for i, m in enumerate(MERCHANT_RISK.keys())}
            merchant_num = merchant_map.get(merchant, len(merchant_map))
            device_num   = 1 if device.lower() in ("unknown", "new device", "unregistered") else 0

            features = np.array([[amount, merchant_num, device_num, hour]])
            prob = model.predict_proba(features)[0][1]
            return round(float(prob), 3)
        except Exception:
            pass

    # Rule-based fallback
    score = 0.0
    if amount > 50000:    score += 0.40
    elif amount > 20000:  score += 0.25
    elif amount > 9999:   score += 0.15
    score += merchant_score * 0.40
    if 0 <= hour < 5:     score += 0.15
    if device.lower() in ("unknown", "new device", "unregistered"):
        score += 0.10

    return round(min(score, 1.0), 3)