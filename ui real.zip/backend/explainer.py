# ─── VEXA Fraud Detection — explainer.py (v2 — AI-powered) ───

import urllib.request
import urllib.error
import json

MERCHANT_RISK = {
    "Crypto Exchange": 0.90,
    "Unknown":         0.85,
    "Wire Transfer":   0.75,
    "Online Gaming":   0.65,
    "International":   0.60,
    "Food Delivery":   0.10,
    "Grocery":         0.08,
    "E-Commerce":      0.15,
    "Utility":         0.05,
    "Medical":         0.10,
}


def _ai_explain(amount, merchant, score, is_fraud):
    """Call Claude API for a smart explanation. Falls back gracefully."""
    verdict = "FRAUDULENT" if is_fraud else "SAFE"
    prompt = (
        f"You are a fraud analyst AI for VEXA, a UPI fraud detection system. "
        f"A transaction was scored {score:.2f}/1.0 and flagged as {verdict}. "
        f"Amount: ₹{amount}, Merchant: {merchant}. "
        f"In exactly 2 short sentences, explain why this transaction {'is suspicious' if is_fraud else 'appears safe'}. "
        f"Be specific about the amount and merchant. Use plain English, no bullet points."
    )
    try:
        payload = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 120,
            "messages": [{"role": "user", "content": prompt}]
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={"content-type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"].strip(), True
    except Exception:
        return None, False


def explain(amount, merchant, score, device="unknown", hour=12):
    """Return explanation dict for a transaction."""
    is_fraud = score >= 0.5
    reasons  = []
    weights  = {}

    # Amount analysis
    if amount > 50000:
        reasons.append("Extremely high transaction amount")
        weights["amount"] = 0.40
    elif amount > 20000:
        reasons.append("High transaction amount")
        weights["amount"] = 0.25
    elif amount > 9999:
        reasons.append("Above-average transaction amount")
        weights["amount"] = 0.15
    else:
        weights["amount"] = 0.05

    # Merchant risk
    merchant_score = MERCHANT_RISK.get(merchant, 0.30)
    if merchant_score >= 0.75:
        reasons.append(f"High-risk merchant category: {merchant}")
        weights["merchant"] = 0.35
    elif merchant_score >= 0.50:
        reasons.append(f"Elevated-risk merchant: {merchant}")
        weights["merchant"] = 0.20
    else:
        weights["merchant"] = 0.05

    # Time-of-day
    if 0 <= hour < 5:
        reasons.append("Transaction at unusual late-night hour")
        weights["time"] = 0.15
    else:
        weights["time"] = 0.02

    # Device
    if device.lower() in ("unknown", "new device", "unregistered"):
        reasons.append("Unrecognized device used")
        weights["device"] = 0.10
    else:
        weights["device"] = 0.02

    if not reasons:
        reasons.append("Transaction profile within normal parameters")

    # Try AI explanation
    ai_text, used_ai = _ai_explain(amount, merchant, score, is_fraud)
    if not ai_text:
        ai_text = f"Score {score:.2f} — {'High fraud probability based on risk factors.' if is_fraud else 'Low risk profile for this transaction.'}"

    return {
        "score":       round(score, 3),
        "is_fraud":    is_fraud,
        "reasons":     reasons,
        "weights":     weights,
        "ai_explanation": ai_text,
        "used_ai":     used_ai,
    }